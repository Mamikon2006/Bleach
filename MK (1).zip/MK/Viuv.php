<!DOCTYPE html>
<html>
<head>
	<title> Bleach </title>
	<link rel="stylesheet" type="text/css" href="staylhimn.css">
</head>
<body>
	<div class="main">
		<?php include "header.php"; ?>

		<div class="content">
			<div class="vidio">

			<div class="dzax1">
				<iframe width="560" height="315" src="https://www.youtube.com/embed/nUZ8P2HIBXI" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
					<form>
					    
					<div>
						<div><label>Your comment</label></div>
						<textarea name="comment"></textarea>
					</div>
					<input type="submit" name="sand" class="input" >

					</form>
				
			</div>
			<div class="aj1">
				<iframe width="560" height="315" src="https://www.youtube.com/embed/FckqLzCVExk" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
				<form>
					    
					<div>
						<div><label>Your comment</label></div>
						<textarea name="comment"></textarea>
					</div>
					<input type="submit" name="sand" class="input" >

					</form>
			</div>
			<div class="dzax1">
				<iframe width="560" height="315" src="https://www.youtube.com/embed/LjBfmmghHPQ" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
				<form>
					    
					<div>
						<div><label>Your comment</label></div>
						<textarea name="comment"></textarea>
					</div>
					<input type="submit" name="sand" class="input" >

					</form>
			</div>
		
		    
			<div class="aj1">
				<iframe width="560" height="315" src="https://www.youtube.com/embed/M84mzkM5KeM" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
					<form>
					    
					<div>
						<div><label>Your comment</label></div>
						<textarea name="comment"></textarea>
					</div>
					<input type="submit" name="sand" class="input" >

					</form>
				
			</div>
		</div>
		</div>
		<div class="footer">
			<div class="logo_box">
				<a href="https://www.instagram.com/official.bleach/?hl=en"><img class="logo1" src="https://upload.wikimedia.org/wikipedia/commons/thumb/e/e7/Instagram_logo_2016.svg/768px-Instagram_logo_2016.svg.png"></a>
			</div>
			<div class="menu_box">
				<ul class="menu">
					<ul class="menu">
					<li> <p class="menu_text">Designed by  Mamikon Kandilyan</p></li>
					</ul>
				</ul>
			</div>
			
		</div>
	</div>

</body>
</html>