<?php 

$db = mysqli_connect('localhost','root','root','MamikonHimn');
if (!$db) {
	die("connection failed".mysqli_connect_error());
}


 ?>