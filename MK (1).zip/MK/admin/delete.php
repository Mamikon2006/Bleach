<form action="delete.php" methot="POST">
<input type="hidden" name="del_user" value="{id пользователя}" />
<input type="submit" value="удалить" />
</form>