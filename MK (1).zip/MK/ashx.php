
<!DOCTYPE html>
<html>
<head>
	<title> Bleach </title>
	<link rel="stylesheet" type="text/css" href="staylhimn.css">
</head>
<body>

<?php include "header.php"; ?>

	<div class="main">
	
		<div class="content">

			<div class="dzax">
				<div class="verev">
					<a href="https://animego.org/anime/blich-170"><img src="https://img3.hulu.com/user/v3/artwork/02a3c8c0-4f1d-4610-bbb4-5b8e9468d7b1?base_image_bucket_name=image_manager&base_image=fb63be54-4aec-4db1-bf27-abea35f293c9&region=US&format=jpeg&size=952x536" class="nkar"></a>
				</div>
				<div class="nerqev">
					<div class="poqr">
			            <img src="https://images-wixmp-ed30a86b8c4ca887773594c2.wixmp.com/f/66618982-ced1-4221-9069-7c8ddf063911/dffsne-a5a58d53-a578-4f00-8bea-122933976c7c.jpg?token=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ1cm46YXBwOjdlMGQxODg5ODIyNjQzNzNhNWYwZDQxNWVhMGQyNmUwIiwiaXNzIjoidXJuOmFwcDo3ZTBkMTg4OTgyMjY0MzczYTVmMGQ0MTVlYTBkMjZlMCIsIm9iaiI6W1t7InBhdGgiOiJcL2ZcLzY2NjE4OTgyLWNlZDEtNDIyMS05MDY5LTdjOGRkZjA2MzkxMVwvZGZmc25lLWE1YTU4ZDUzLWE1NzgtNGYwMC04YmVhLTEyMjkzMzk3NmM3Yy5qcGcifV1dLCJhdWQiOlsidXJuOnNlcnZpY2U6ZmlsZS5kb3dubG9hZCJdfQ.WVmQAe0D0ttM250iTt7c0y-GmWtNQmm9H7lMJpOi8-w" class="nkar">
					</div>
					<div class="poqr">
						<img src="https://images-wixmp-ed30a86b8c4ca887773594c2.wixmp.com/f/66618982-ced1-4221-9069-7c8ddf063911/dffsne-a5a58d53-a578-4f00-8bea-122933976c7c.jpg?token=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ1cm46YXBwOjdlMGQxODg5ODIyNjQzNzNhNWYwZDQxNWVhMGQyNmUwIiwiaXNzIjoidXJuOmFwcDo3ZTBkMTg4OTgyMjY0MzczYTVmMGQ0MTVlYTBkMjZlMCIsIm9iaiI6W1t7InBhdGgiOiJcL2ZcLzY2NjE4OTgyLWNlZDEtNDIyMS05MDY5LTdjOGRkZjA2MzkxMVwvZGZmc25lLWE1YTU4ZDUzLWE1NzgtNGYwMC04YmVhLTEyMjkzMzk3NmM3Yy5qcGcifV1dLCJhdWQiOlsidXJuOnNlcnZpY2U6ZmlsZS5kb3dubG9hZCJdfQ.WVmQAe0D0ttM250iTt7c0y-GmWtNQmm9H7lMJpOi8-w" class="nkar">
					</div>
					<div class="poqr">
						<img src="https://images-wixmp-ed30a86b8c4ca887773594c2.wixmp.com/f/66618982-ced1-4221-9069-7c8ddf063911/dffsne-a5a58d53-a578-4f00-8bea-122933976c7c.jpg?token=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ1cm46YXBwOjdlMGQxODg5ODIyNjQzNzNhNWYwZDQxNWVhMGQyNmUwIiwiaXNzIjoidXJuOmFwcDo3ZTBkMTg4OTgyMjY0MzczYTVmMGQ0MTVlYTBkMjZlMCIsIm9iaiI6W1t7InBhdGgiOiJcL2ZcLzY2NjE4OTgyLWNlZDEtNDIyMS05MDY5LTdjOGRkZjA2MzkxMVwvZGZmc25lLWE1YTU4ZDUzLWE1NzgtNGYwMC04YmVhLTEyMjkzMzk3NmM3Yy5qcGcifV1dLCJhdWQiOlsidXJuOnNlcnZpY2U6ZmlsZS5kb3dubG9hZCJdfQ.WVmQAe0D0ttM250iTt7c0y-GmWtNQmm9H7lMJpOi8-w" class="nkar">
					</div>
				</div>
			</div>
			<div class="aj">
				<h1 class="vernagir">
					BLEACH
				</h1>
				<p class="text">
					Bleach (stylized in all caps) is a Japanese anime television series based on Tite Kubo's original manga series of the same name. It was produced by Studio Pierrot and directed by Noriyuki Abe. The series aired on TV Tokyo from October 2004 to March 2012, spanning 366 episodes. The story follows the adventures of Ichigo Kurosaki after he obtains the powers of a Soul Reaper—a death personification similar to the Grim Reaper—from another Soul Reaper, Rukia Kuchiki. His newfound powers force him to take on the duties of defending humans from evil spirits and guiding departed souls to the afterlife. In addition to adapting the manga series it is based on, the anime periodically includes original self-contained storylines and characters not found in the manga.<br>The series adapts Kubo's manga with the main story arcs and introduces anime exclusive ones. In Karakura Town, high school student Ichigo Kurosaki becomes a substitute Soul Reaper (死神, Shinigami, literally, "Death God"), when Rukia Kuchiki risks her life to protect him from a Hollow. Although initially reluctant to accept their responsibility, he takes her place, and during this time they discover that a few classmates are spiritually aware and have their own powers: Quincy survivor Uryū Ishida uses spiritual particles, Orihime Inoue has a group of protective spirits called Shun Shun Rikka and Yasutora Sado ("Chad") has strength equal to the Hollows encased in his arm.<br>When Rukia is sentenced to death for transgressions in the human world and sent to the Soul Society, Ichigo meets Kisuke Urahara and Yoruichi Shihōin, the duo of exiled Soul Reapers. They allow him and his friends to save Rukia. After this, it is revealed that ex-squad captain Sōsuke Aizen framed Rukia for the crime and has been illegally experimenting on Soul Reapers and Hollows. Aizen plans to conquer the Soul Society by using the Hōgyoku, a legendary powerful substance turning Hollows into half Soul Reapers. After faking his death and his reappearance caused a fight with some people, Aizen escapes into Hueco Mundo, the realm of Hollows, and later kidnaps Orihime as she is instrumental in creating the Oken, a power that will allow him to kill the Soul King, the ruler of the Soul Society.
				</p>
				<a href="https://en.wikipedia.org/wiki/Bleach_(TV_series)" class="link1">View more</a>
				<a href="https://en.wikipedia.org/wiki/Bleach_(manga)" class="link2">View more</a>
			</div>
		</div>
		<?php include "futer.php"; ?>
	</div>

</body>
</html>