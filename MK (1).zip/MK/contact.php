<!DOCTYPE html>
<html>
<head>
	<title> Bleach </title>
	<link rel="stylesheet" type="text/css" href="staylhimn.css">
</head>
<body>
	<div class="main">
		<?php include "header.php"; ?>
		<div class="content">

			<div class="dzax">
					<form>
					    <h2>Contact the operator</h2>
					    <div>
						<input type="text" name="anun" placeholder="anun" class="input">
					</div>
					<div>
						<input type="text" name="azganun" placeholder="azganun" class="input">
					</div>
					<div>
						<input type="email" name="email" placeholder="email" class="input">
					</div>
					<div>
						<input type="password" name="password" placeholder="password" class="input">
					</div>
					<div>
						<input type="date" name="date" class="input">
					</div>
					<div>
						<div><label>Your screenshot</label></div>
						<input type="file" name="file" class="input">
					</div>
					<div>
						<div><label>Your comment</label></div>
						<textarea name="comment"></textarea>
						<input type="submit" name="sand" class="input" >
					</div>

					</form>
				
			</div>
			<div class="aj">
				<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3047.8455441799692!2d44.51998801591125!3d40.1902506793922!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x406abd208e74a297%3A0xdfb55f9bbd4e0089!2sNational%20Polytechnic%20University%20of%20Armenia!5e0!3m2!1sen!2sam!4v1677410445377!5m2!1sen!2sam" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade" class="iframe"></iframe>
			</div>
		</div>
		<?php include "futer.php"; ?>
	</div>

</body>
</html>