
<div class="footer">
			<div class="logo_box">
				<a href="https://www.instagram.com/official.bleach/?hl=en"><img class="logo1" src="https://upload.wikimedia.org/wikipedia/commons/thumb/e/e7/Instagram_logo_2016.svg/768px-Instagram_logo_2016.svg.png"></a>
			</div>
			<div class="menu_box">
				<ul class="menu">
					<ul class="menu">
					<li> <p class="menu_text">Designed by  Mamikon Kandilyan</p></li>
					</ul>
				</ul>
			</div>
			
		</div>


