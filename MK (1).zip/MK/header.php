
<div class="header">
			<div class="logo_box">
				<img class="logo" src="https://mbsaen.oasgames.com/assets/img/logo.8ceb75da.png">
			</div>
			<div class="menu_box">
				<ul class="menu">
					<li> <a class="menu_link" href="ashx.php">Home</a> </li>
					<li> <a class="menu_link" href="shop.php">Shop</a> </li>
					<li> <a class="menu_link" href="contact.php">Contact</a> </li>
					<li> <a class="menu_link" href="page.php">Page</a> </li>
					<li> <a class="menu_link" href="Viuv.php"> Viuv</a> </li>
				</ul>
			</div>
		</div> 
