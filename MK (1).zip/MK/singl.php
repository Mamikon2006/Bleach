<!DOCTYPE html>
<html>
<head>
	<title> Bleach </title>
	<link rel="stylesheet" type="text/css" href="staylhimn.css">
</head>
<body>
	<div class="main">
		<?php include "header.php"; ?>

		<div class="content">

			<div class="dzax">
				<div class="verev">
					<img src="https://imaginaire.com/en/images/BLEACH--ICHIGO-KUROSAKI-33-X-44__0699858997169-Z.JPG" class="nkar">
				</div>
				
			</div>
			<div class="aj">
				<h1 class="vernagir">
					Manga-Box
				</h1>
				<p class="text">
					Part-time student, full-time Soul Reaper, Ichigo is one of the chosen few guardians of the afterlife.<br>

Ichigo Kurosaki never asked for the ability to see ghosts—he was born with the gift. When his family is attacked by a Hollow—a malevolent lost soul—Ichigo becomes a Soul Reaper, dedicating his life to protecting the innocent and helping the tortured spirits themselves find peace. Find out why Tite Kubo’s Bleach has become an international manga smash-hit!
				</p>
				<img class="nkar" src="https://reviewingshelf.files.wordpress.com/2017/11/images.png?w=1086">
				<table>
    <tr>
    		<td>1.</td>
    		<td>Product quality</td> 
    		<td>4/5</td>
    </tr>
    <tr>
    		<td>2.</td>
   		<td>Average delivery time</td> 
    		<td>3 dey</td>
    </tr>
    <tr>
    		<td>3.</td>
    		<td>Evaluation</td>  
    		<td>4.5/5</td>
    </tr>
				</table>
			</div>
		</div>
		<?php include "futer.php"; ?>
	</div>

</body>
</html>